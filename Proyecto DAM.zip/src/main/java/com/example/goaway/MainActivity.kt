package com.example.goaway

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.modifier.modifierLocalOf
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.goaway.ui.theme.GoAwayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GoAwayTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    PantallaLogInGoAway()
                }
            }
        }
    }
}

@Composable
fun PantallaLogInGoAway(){

    Column (
        modifier = Modifier.padding(32.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),

    ) {
        Text(
            text = stringResource(id = R.string.Inicio_Go_Away),
            fontSize = 24.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(modifier = Modifier.height(16.dp))
        CampoTexto()
    }
}

@Composable
fun CampoTexto() {
    var CantidadInput by remember {
        mutableStateOf("")
    }
    TextField(
        value = CantidadInput,
        onValueChange = {CantidadInput = it},
        label = { Text(text = stringResource(id = R.string.Usuario_o_correo_electrónico))},
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
    )
    var ContraseñaInput by remember {
        mutableStateOf("")
    }
    TextField(
        value = ContraseñaInput,
        onValueChange = {ContraseñaInput = it},
        label = { Text(text = stringResource(id = R.string.Contraseña))},
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
    )
}



@Preview(showBackground = true)
@Composable
fun VistaDefault() {
    GoAwayTheme {
        PantallaLogInGoAway()
    }
}